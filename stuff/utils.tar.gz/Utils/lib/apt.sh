usage(){
    echo "$1"
    exit 1
}
apti_doc='An alias for: sudo apt-get install'
apti_arg='<pattern>'
 apti(){
   echo "boo"
}
